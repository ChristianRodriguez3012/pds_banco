package com.example.newtronic_banking

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
